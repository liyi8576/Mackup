//
//  PxCookDuplicate.h
//  PxCookDuplicate
//
//  Created by featherJ_old on 2017/5/16.
//  Copyright © 2017年 fancynode. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for PxCookDuplicate.
FOUNDATION_EXPORT double PxCookDuplicateVersionNumber;

//! Project version string for PxCookDuplicate.
FOUNDATION_EXPORT const unsigned char PxCookDuplicateVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PxCookDuplicate/PublicHeader.h>


