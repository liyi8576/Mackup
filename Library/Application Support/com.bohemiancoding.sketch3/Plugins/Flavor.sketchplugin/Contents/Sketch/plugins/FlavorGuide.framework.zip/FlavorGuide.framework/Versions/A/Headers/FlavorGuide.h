//
//  FlavorGuide.h
//  FlavorGuide
//
//  Created by featherJ_old on 2017/6/16.
//  Copyright © 2017年 fancynode. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for FlavorGuide.
FOUNDATION_EXPORT double FlavorGuideVersionNumber;

//! Project version string for FlavorGuide.
FOUNDATION_EXPORT const unsigned char FlavorGuideVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FlavorGuide/PublicHeader.h>


